$(function(){
	$("#submit").click(function(event){
		$.post("url",{
			user_name: $("#user_name").val(),
			user_email: $("#user_email").val(),
			phone: $("#phone").val(),
			passward: $("#phone").val()
		},function(data,textStatus){
			location.href = "menu.html"
		})
	})
})
$(function(){
	$("#button").click(function(event){
		$.post("url",{
			user_name: $("#user_name").val(),
			passward: $("#phone").val()
		},function(data,textStatus){
				location.href = "menu.html"
		})
	})
})