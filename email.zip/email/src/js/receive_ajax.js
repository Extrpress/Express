$(function(){
	$.post("url",function(data,textStatus){
		
	})
})