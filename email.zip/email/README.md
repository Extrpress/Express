# the gulp

1.克隆到本地

2.npm install 安装依赖

3.构建
  + 如果不需要合并css和js，使用gulp构建
  + 如果需要合并使用gulp concat构建
